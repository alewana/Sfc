const net = require('net');

const clients = [];

const server = net.createServer((socket) => {
  socket.setEncoding('utf8');
  const clientInfo = `${socket.remoteAddress}:${socket.remotePort}`;
  console.log(`🌐 New connection: ${clientInfo}`);
  clients.push(socket);

  socket.on('end', () => {
    console.log(`❌ Connection closed: ${clientInfo}`);
    const index = clients.indexOf(socket);
    if (index > -1) clients.splice(index, 1);
  });

  socket.on('error', (err) => {
    console.error(`⚠️ Terminal error (${clientInfo}): ${err.message}`);
  });
});

function broadcastCommand(cmd) {
  console.log(`📡 Broadcasting command: ${cmd}`);
  clients.forEach((client) => {
    try {
      client.write(cmd + '\n');
      console.log(`🔺 Sent to ${client.remoteAddress}: ${cmd}`);
    } catch (e) {
      console.error(`❌ Failed to send to ${client.remoteAddress}: ${e.message}`);
    }
  });
}

function getConnectedTerminals() {
  return clients.map(client => `${client.remoteAddress}:${client.remotePort}`);
}

module.exports = {
  server,
  broadcastCommand,
  getConnectedTerminals
};